// eslint-disable-next-line
import React, { Component } from "react";
import axios from "axios";

import "./assets/file-tracking.css";

class FileTracking extends Component {
  constructor(props) {
    super(props);
    this.state = {
      add_logs: [],
      change_logs: [],
      unlink_logs: [],
      addDir_logs: [],
      unlinkDir_logs: [],
      error_logs: [],
      ready_logs: [],
      active: ""
    };
  }

  getData() {
    axios
      .get(`http://localhost:4000/`, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-type": "application/x-www-form-urlencoded",
          Accept: "application/json"
        }
      })
      .then(resp => {
        this.setState({
          add_logs: resp.data.File_add_logs.add_logs
            .substring(resp.data.File_add_logs.add_logs.indexOf("&") + 1)
            .split("&"),
          change_logs: resp.data.File_change_logs.change_logs
            .substring(resp.data.File_change_logs.change_logs.indexOf("&") + 1)
            .split("&"),
          unlink_logs: resp.data.File_unlink_logs.unlink_logs
            .substring(resp.data.File_unlink_logs.unlink_logs.indexOf("&") + 1)
            .split("&"),
          addDir_logs: resp.data.File_addDir_logs.addDir_logs
            .substring(resp.data.File_addDir_logs.addDir_logs.indexOf("&") + 1)
            .split("&"),
          unlinkDir_logs: resp.data.File_unlinkDir_logs.unlinkDir_logs
            .substring(
              resp.data.File_unlinkDir_logs.unlinkDir_logs.indexOf("&") + 1
            )
            .split("&"),
          error_logs: resp.data.File_error_logs.error_logs
            .substring(resp.data.File_error_logs.error_logs.indexOf("&") + 1)
            .split("&"),
          ready_logs: resp.data.File_ready_logs.ready_logs
            .substring(resp.data.File_ready_logs.ready_logs.indexOf("&") + 1)
            .split("&")
        });
      });
  }

  componentWillMount() {
    this.getData();
  }

  render() {
    var value_add = this.state.add_logs.map((data, i) => {
      return (
        <h6 style={{ textAlign: "left" }} key={i}>
          {i + 1}.&nbsp;&nbsp;&nbsp;&nbsp;{data}
        </h6>
      );
    });
    var value_change = this.state.change_logs.map((data, i) => {
      return (
        <h6 style={{ textAlign: "left" }} key={i}>
          {i + 1}.)&nbsp;&nbsp;&nbsp;{data}
        </h6>
      );
    });
    var value_unlink = this.state.unlink_logs.map((data, i) => {
      return (
        <h6 style={{ textAlign: "left" }} key={i}>
          {i + 1}.)&nbsp;&nbsp;&nbsp;{data}
        </h6>
      );
    });
    var value_addDir = this.state.addDir_logs.map((data, i) => {
      return (
        <h6 style={{ textAlign: "left" }} key={i}>
          {i + 1}.)&nbsp;&nbsp;&nbsp;{data}
        </h6>
      );
    });
    var value_unlinkDir = this.state.unlinkDir_logs.map((data, i) => {
      return (
        <h6 style={{ textAlign: "left" }} key={i}>
          {i + 1}.)&nbsp;&nbsp;&nbsp;{data}
        </h6>
      );
    });
    var value_error = this.state.error_logs.map((data, i) => {
      return (
        <h6 style={{ textAlign: "left" }} key={i}>
          {i + 1}.)&nbsp;&nbsp;&nbsp;{data}
        </h6>
      );
    });
    var value_ready = this.state.ready_logs.map((data, i) => {
      return (
        <h6 style={{ textAlign: "left" }} key={i}>
          {i + 1}.)&nbsp;&nbsp;&nbsp;{data}
        </h6>
      );
    });
    return (
      <div className="App">
        <div
          class="modal fade bd-example-modal-lg"
          id="exampleModalCenter"
          tabindex="-1"
          role="dialog"
          aria-labelledby="exampleModalCenterTitle"
          aria-hidden="true"
        >
          <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">
                  {this.state.active + " Details"}
                </h5>
                <button
                  type="button"
                  class="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                {this.state.active === "Directory Added"
                  ? value_addDir
                  : this.state.active === "Directory Removed"
                  ? value_unlinkDir
                  : this.state.active === "File Added"
                  ? value_add
                  : this.state.active === "File Changed"
                  ? value_change
                  : this.state.active === "File Removed"
                  ? value_unlink
                  : this.state.active === "File Error Logs"
                  ? value_error
                  : this.state.active === "File Ready Logs"
                  ? value_ready
                  : null}
              </div>
              <div class="modal-footer">
                <button
                  type="button"
                  class="btn btn-secondary"
                  data-dismiss="modal"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
        <br />
        <h1>File Tracking System</h1>
        <br />
        <br />

        <h2>Directory Tracking</h2>
        <buttontoolbar>
          <button
            className="myButton"
            variant="directory_added"
            data-toggle="modal"
            data-target="#exampleModalCenter"
            onClick={() => this.setState({ active: "Directory Added" })}
          >
            Directory Added
          </button>
          <button
            className="myButton"
            variant="directory_removed"
            data-toggle="modal"
            data-target="#exampleModalCenter"
            onClick={() => this.setState({ active: "Directory Removed" })}
          >
            Directory Removed
          </button>
        </buttontoolbar>
        <br />
        <h2>File Tracking</h2>
        <buttontoolbar>
          <button
            className="myButton"
            variant="file_added"
            data-toggle="modal"
            data-target="#exampleModalCenter"
            onClick={() => this.setState({ active: "File Added" })}
          >
            File Added
          </button>
          <button
            className="myButton"
            variant="file_changed"
            data-toggle="modal"
            data-target="#exampleModalCenter"
            onClick={() => this.setState({ active: "File Changed" })}
          >
            File Changed
          </button>
          <button
            className="myButton"
            variant="file_removed"
            data-toggle="modal"
            data-target="#exampleModalCenter"
            onClick={() => this.setState({ active: "File Removed" })}
          >
            File Removed
          </button>
        </buttontoolbar>
        <br />
        <h2>File Logs Tracking</h2>
        <buttontoolbar>
          <button
            className="myButton"
            variant="file_error_logs"
            data-toggle="modal"
            data-target="#exampleModalCenter"
            onClick={() => this.setState({ active: "File Error Logs" })}
          >
            File Error Logs
          </button>
          <button
            className="myButton"
            variant="file_ready_logs"
            data-toggle="modal"
            data-target="#exampleModalCenter"
            onClick={() => this.setState({ active: "File Ready Logs" })}
          >
            File Ready Logs
          </button>
        </buttontoolbar>
      </div>
    );
  }
}

export default FileTracking;
