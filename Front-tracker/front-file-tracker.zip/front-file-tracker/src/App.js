// eslint-disable-next-line
import React, { Component } from "react";

import Login from "./components/login/Login";
import FileTracker from "./components/file-tracking-frontend/file-tracking";

class App extends Component {
  render() {
    // return <Login />;
    return <FileTracker />;
  }
}

export default App;
